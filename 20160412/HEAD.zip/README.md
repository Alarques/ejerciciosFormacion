# FormacioJava2016
## Estructura bàsica de projecte Maven

Estructura creada mitjançant la comanda
mvn archetype:generate -DgroupId=com.indra.formacio -DartifactId=Model -DarchetypeArtifactId=maven-archetype-quickstart -DinteractiveMode=false

Afegides classes del model
Afegit joc de proves de getters i setters

Afegida configuració mínima JPA i DB Derby autogenerada.