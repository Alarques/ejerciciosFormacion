package com.indra.formacio.webmodel;

public class EmployeeSearchForm {
	
	private String name;
	
	private String surname;
	
	private String birthdayIni;
	
	private String birthdayEnd;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getBirthdayIni() {
		return birthdayIni;
	}

	public void setBirthdayIni(String birthdayIni) {
		this.birthdayIni = birthdayIni;
	}

	public String getBirthdayEnd() {
		return birthdayEnd;
	}

	public void setBirthdayEnd(String birthdayEnd) {
		this.birthdayEnd = birthdayEnd;
	}

	
	

}
